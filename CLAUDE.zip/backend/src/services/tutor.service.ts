import { z } from 'zod';
import { db, conversations, conversationMessages } from '@/db';
import { eq, asc } from 'drizzle-orm';
import { aiGateway } from '@/ai/gateway';
import { buildSystemPrompt } from '@/config/subjects';
import type { TutorMode } from '@/config/subjects';
import type { KnowledgeChunk, AIMessage } from '@/ai/types';

// ── Structured response schema ────────────────────────────────────────────────

export const TutorStepSchema = z.object({
  number: z.number().int().positive(),
  title: z.string().min(1),
  content: z.string().min(1),
});

export const TutorMisconceptionSchema = z.object({
  misconception: z.string().min(1),
  correction: z.string().min(1),
});

export const TutorStructuredResponseSchema = z.object({
  explanation: z.string().min(1),
  steps: z.array(TutorStepSchema).min(1),
  hints: z.array(z.string()).min(1).max(5),
  misconceptions: z.array(TutorMisconceptionSchema).optional().default([]),
  socraticQuestion: z.string().optional(),
});

export type TutorStructuredResponse = z.infer<typeof TutorStructuredResponseSchema>;

export interface TutorQuestion {
  text: string;
  imageUrls?: string[];
  imageData?: string; // base64 image for Gemini Vision
  userId: string;
  subjectId?: string;
  conversationId?: string;
  mode?: TutorMode;
  topic?: string;
  subtopic?: string;
}

export interface TutorFullResponse {
  structured: TutorStructuredResponse;
  conversationId: string;
  messageId: string;
  sourceChunks: Array<{ id: string; text: string; source: string }>;
  rawText: string;
}

const MAX_HISTORY_MESSAGES = 6;

export class TutorService {
  static async answerQuestion(
    question: TutorQuestion,
    ragContext: KnowledgeChunk[]
  ): Promise<TutorFullResponse> {
    const subjectId = question.subjectId ?? 'physics';
    const systemPrompt = buildSystemPrompt(question.mode);

    await aiGateway.initializeForUser(question.userId);

    const convId = await this.getOrCreateConversation(
      question.userId, question.text, subjectId, question.conversationId
    );

    const history = await this.loadHistory(convId);
    const contextText = this.buildContextFromChunks(ragContext);
    const userMessageContent = this.buildUserPrompt(
      question.text, contextText, question.topic, question.subtopic
    );

    await db.insert(conversationMessages).values({
      conversationId: convId, role: 'user', content: userMessageContent,
    });

    const messages: AIMessage[] = [
      ...history,
      { role: 'user', content: userMessageContent },
    ];

    const aiResponse = await aiGateway.generateResponse({
      messages, systemPrompt, maxTokens: 2048, temperature: 0.7,
    });

    const structured = this.parseStructuredResponse(aiResponse.content);

    const [savedAssistantMsg] = await db
      .insert(conversationMessages)
      .values({ conversationId: convId, role: 'assistant', content: aiResponse.content, structuredData: structured })
      .returning({ id: conversationMessages.id });

    await db.update(conversations).set({ updatedAt: new Date() }).where(eq(conversations.id, convId));

    return {
      structured,
      conversationId: convId,
      messageId: savedAssistantMsg.id,
      rawText: aiResponse.content,
      sourceChunks: ragContext.map((c) => ({ id: c.id, text: c.text.substring(0, 200), source: c.source })),
    };
  }

  static async *streamAnswer(
    question: TutorQuestion,
    ragContext: KnowledgeChunk[]
  ): AsyncGenerator<{ type: 'delta'; text: string } | { type: 'done'; data: TutorFullResponse }> {
    const subjectId = question.subjectId ?? 'physics';
    const systemPrompt = buildSystemPrompt(question.mode);

    const convId = await this.getOrCreateConversation(
      question.userId, question.text, subjectId, question.conversationId
    );

    const history = await this.loadHistory(convId);
    const contextText = this.buildContextFromChunks(ragContext);
    const userMessageContent = this.buildUserPrompt(
      question.text, contextText, question.topic, question.subtopic
    );

    await db.insert(conversationMessages).values({
      conversationId: convId, role: 'user', content: userMessageContent,
    });

    // ── Gemini direct call (supports Vision when imageData present) ──────────
    const apiKey = process.env.DEMO_GEMINI_API_KEY;
    if (!apiKey) throw new Error('DEMO_GEMINI_API_KEY is not configured');

    const modelName = 'gemini-1.5-flash';
    const promptText = `${systemPrompt}\n\n${userMessageContent}`;

    // Build history parts for multi-turn
    const historyContents = history.map((m) => ({
      role: m.role === 'assistant' ? 'model' : 'user',
      parts: [{ text: m.content }],
    }));

    // Build current user turn parts
    type GeminiPart = { text: string } | { inline_data: { mime_type: string; data: string } };
    const currentParts: GeminiPart[] = question.imageData
      ? [
          { text: promptText },
          { inline_data: { mime_type: 'image/jpeg', data: question.imageData } },
        ]
      : [{ text: promptText }];

    const contents = [
      ...historyContents,
      { role: 'user', parts: currentParts },
    ];

    const streamUrl = `https://generativelanguage.googleapis.com/v1beta/models/${modelName}:streamGenerateContent?alt=sse&key=${apiKey}`;

    const geminiRes = await fetch(streamUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ contents }),
    });

    if (!geminiRes.ok) {
      const errData = (await geminiRes.json()) as { error?: { message?: string } };
      throw new Error(errData.error?.message || `Gemini API error: ${geminiRes.status}`);
    }

    // Parse SSE stream from Gemini
    const reader = geminiRes.body!.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    let fullText = '';

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() ?? '';

      for (const line of lines) {
        if (!line.startsWith('data: ')) continue;
        const raw = line.slice(6).trim();
        if (!raw || raw === '[DONE]') continue;
        try {
          const parsed = JSON.parse(raw) as {
            candidates?: Array<{ content?: { parts?: Array<{ text?: string }> } }>;
          };
          const delta = parsed.candidates?.[0]?.content?.parts?.[0]?.text ?? '';
          if (delta) {
            fullText += delta;
            yield { type: 'delta', text: delta };
          }
        } catch { /* skip malformed lines */ }
      }
    }

    const structured = this.parseStructuredResponse(fullText);

    const [savedMsg] = await db
      .insert(conversationMessages)
      .values({ conversationId: convId, role: 'assistant', content: fullText, structuredData: structured })
      .returning({ id: conversationMessages.id });

    await db.update(conversations).set({ updatedAt: new Date() }).where(eq(conversations.id, convId));

    yield {
      type: 'done',
      data: {
        structured,
        conversationId: convId,
        messageId: savedMsg.id,
        rawText: fullText,
        sourceChunks: ragContext.map((c) => ({ id: c.id, text: c.text.substring(0, 200), source: c.source })),
      },
    };
  }

  static async generateHint(
    questionText: string,
    previousExplanation: string,
    ragContext: KnowledgeChunk[],
    userId: string = ''
  ): Promise<string> {
    if (userId) await aiGateway.initializeForUser(userId);

    const hintPrompt = `שאלה מקורית: ${questionText}\n\nההסבר הקודם:\n${previousExplanation}\n\nתן רמז קצר אחד (משפט-שניים) שמוביל לחשיבה עצמאית. לא לתת תשובה. עברית בלבד.`;

    const response = await aiGateway.generateResponse({
      messages: [{ role: 'user', content: hintPrompt }],
      systemPrompt: buildSystemPrompt('concept'),
      maxTokens: 300,
      temperature: 0.6,
    });

    return response.content;
  }

  private static async getOrCreateConversation(
    userId: string, questionText: string, subjectId: string, existingConvId?: string
  ): Promise<string> {
    if (existingConvId) {
      const existing = await db
        .select({ id: conversations.id })
        .from(conversations)
        .where(eq(conversations.id, existingConvId))
        .limit(1);
      if (existing.length > 0) return existingConvId;
    }

    const title = questionText.length > 80 ? questionText.substring(0, 77) + '...' : questionText;
    const [conv] = await db
      .insert(conversations)
      .values({ userId, title, subject: subjectId })
      .returning({ id: conversations.id });

    return conv.id;
  }

  private static async loadHistory(conversationId: string): Promise<AIMessage[]> {
    const messages = await db
      .select({ role: conversationMessages.role, content: conversationMessages.content })
      .from(conversationMessages)
      .where(eq(conversationMessages.conversationId, conversationId))
      .orderBy(asc(conversationMessages.createdAt))
      .limit(MAX_HISTORY_MESSAGES);

    return messages.map((m) => ({ role: m.role as 'user' | 'assistant', content: m.content }));
  }

  private static buildUserPrompt(
    questionText: string, contextText: string, topic?: string, subtopic?: string
  ): string {
    const topicLine = topic ? `\nנושא: ${topic}${subtopic ? ` → ${subtopic}` : ''}` : '';
    return `שאלה: ${questionText}${topicLine}\n\n${contextText ? `חומר לימוד רלוונטי:\n${contextText}` : ''}\n\nענה בפורמט JSON המדויק. ללא מלל מחוץ לאובייקט ה-JSON.`;
  }

  private static buildContextFromChunks(chunks: KnowledgeChunk[]): string {
    if (chunks.length === 0) return '';
    return chunks.map((c, i) => `[מקור ${i + 1}: ${c.source}]\n${c.text}`).join('\n\n---\n\n');
  }

  private static parseStructuredResponse(rawText: string): TutorStructuredResponse {
    const cleaned = rawText
      .replace(/^```json\s*/m, '')
      .replace(/^```\s*/m, '')
      .replace(/```\s*$/m, '')
      .trim();

    try {
      const parsed = JSON.parse(cleaned);
      return TutorStructuredResponseSchema.parse(parsed);
    } catch {
      return {
        explanation: rawText,
        steps: [{ number: 1, title: 'הסבר', content: rawText }],
        hints: ['קרא שוב את השאלה בעיון', 'חשוב על מה נדרש', 'נסה לפרק לחלקים קטנים'],
        misconceptions: [],
        socraticQuestion: undefined,
      };
    }
  }
}
